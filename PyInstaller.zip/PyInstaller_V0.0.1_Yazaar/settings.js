﻿var settings = {
  "Permission": "Everyone",
  "PermissionInfo": "",
  "Command": "!pyinstall",
  "Cooldown": 60
};