﻿var settings = {
  "Permission": "Caster",
  "PermissionInfo": "",
  "Cooldown": 60,
  "PyPath": "Python",
  "Command": "!pyinstall"
};